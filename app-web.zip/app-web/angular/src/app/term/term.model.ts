import { Attributes } from './message';

/**
 * Represents a data for dynamic fields.
 */
export class Data {
    /* FIELDS ============================================================== */
    public initialValue: string;
    public forceModified: boolean;
    public disabled: boolean;
    public protected: boolean;

    /** Equivalent to the 3270/5250 input field MDT flag: true if the field was modified or if forced by the backend */
    private modified: boolean;

    /* CONSTRUCTORS ======================================================== */
    constructor(
        public value?: string,
        public legacyName?: string,
        public attributes?: Attributes,
        public initialCursor?: boolean,
	    public cursorLine?: number,
	    public cursorColumn?: number
    ) {
        this.initialValue = value;
        this.forceModified = false; // Unused from now on, see AbstTermComponent#fillData
        this.disabled = false;
        this.protected = false;
        this.modified = false;
    }

    public clone(): Data {
        let cloneData = new Data(undefined, this.legacyName, this.attributes, this.initialCursor, this.cursorLine, this.cursorColumn);
        cloneData.value = this.value;
        cloneData.initialValue = this.initialValue;
        cloneData.forceModified = this.forceModified;
        cloneData.disabled = this.disabled;
        cloneData.protected = this.protected;
        cloneData.modified = this.modified;
        return cloneData;
    }

    /**
     * Returns true if user entered a value in this field, or if field is "forced modified".
     * Equivalent to the 3270 MDT field (stays true once set).
     */
    public isModified(): boolean {
        // Sanitize existing value; may not be initialized since objects generated in components
        // are "properties only" objects and not instances of Data (=> constructor not necessarily called)
        if (this.modified === undefined || this.modified === null) {
            this.modified = false;
        }

        // Set "modified" flag if forced or if user changed field value; keep its value otherwise (V7-7068)
        if (this.forceModified || this.isValueChangedByUser()) {
            this.modified = true;
        }

        return this.modified;
    }

    /** Reset the "modified" field */
    public clearModified(): void {
        this.modified = false;
    }

    /** Set the "modified" field */
    public setModified(): void {
        this.modified = true;
    }

    private isValueChangedByUser(): boolean {
        let modified: boolean = this.value != this.initialValue;

        // If no initial value, let's consider blank value as no modified field
        if (this.initialValue === undefined && typeof this.value === 'string' && this.value.trim() === '') {
            modified = false;
        }
	    return modified;
    }
    
    /*
	 * Set good color with attributes
	 * See https://www.ibm.com/support/knowledgecenter/ssw_ibm_i_72/rzakc/rzakcmstdfcolor.htm
	 * 
	 */
	public setCombinationsAttributes(): void {
		// In some combinations of COLOR and DSPATR, both keywords have effect.
		// In some combinations of the COLOR and DSPATR keywords, some of the parameter values are ignored.
		let color: string = this.attributes.color;
		let highlight: string = this.attributes.highlight;
		let intensity: string = this.attributes.intensity;
		let protection: string = this.attributes.protection;
		let password = intensity === 'PWD';
		if (password) {
			this.attributes.isPassword = true;
			intensity = 'NORM';
			if (!color) {
				color = 'DEFAULT';
			}
		} else {
			// ND (nondisplay) - All colors are ignored
			if (intensity === 'DRK') {
				// Change dark to hidden to remove field space on screen
				intensity = 'HIDDEN'; 
				color = '';
			} else {
				if (color) {
					// HI is ignored
					intensity = '';
					// TODO CS is ignored
					// The only color that can blink is red.
					if (color !== 'RED' && highlight === 'BLINK') {
						highlight = '';
					}
				} else {
					if (this.attributes.columnSeparator) {
						if (intensity === 'high') {
							if (highlight === 'BLINK') {
								color = 'BLUE';
							} else {
								color = 'YELLOW';
							}
						} else {
							if (highlight === 'BLINK') {
								color = 'PINK';
							} else {
								color = 'TURQUOISE';
							}
						}
					} else {
						if (intensity === 'high') {
							if (highlight === 'BLINK') {
								color = 'RED';
							} else {
								color = 'WHITE';
							}
						} else {
							if (highlight === 'BLINK') {
								color = 'RED';
							} else {
								color = 'DEFAULT';
							}
						}
					}
				}
				// Set empty attributes with default value
				if (!color) {
					color = 'DEFAULT';
				}
				if (!intensity) {
					intensity = 'NORM';
				}
			}
		}
		if (!protection) {
			protection = 'ASKIP';
		}
		this.attributes.color = color;
		this.attributes.highlight = highlight;
		this.attributes.intensity = intensity;
		this.attributes.protection = protection;
	}
}

/**
 * Represents a group of data for update fields in maps.
 */
export class Token {
    /* FIELDS ============================================================== */
    public modal: string;

    /* CONSTRUCTORS ======================================================== */
    constructor( public children: TokenField[] ) {}
}

/**
 * Represents an update operation on field in map with data.
 */
export class TokenField {
    /* CONSTRUCTORS ======================================================== */
    constructor(
        public map: string,
        public field: string,
        public data: string,
    ) {}
}