
export abstract class MaskFieldComponent {

    protected isFixedCharacterMask(maskChar: string): boolean {
		return '0' != maskChar && 'A' != maskChar && 'S' != maskChar;
	}

	protected getOffSetIndexRawValue(maskValue: string, start: number): number {
		let indexRaw : number =0;
		for (let i = 0; i < maskValue.length && i < start; i++) {

			let maskChar = maskValue.substring(i,i+1);
			if (!this.isFixedCharacterMask(maskChar)) {
				indexRaw++;
			}
		}

		return indexRaw;
	}

	protected getRawValue(maskValue: string, formatedValue: string): string {

		let rawValue : string ="";
		for (let i = 0; i < formatedValue.length; i++) {

			let maskChar = maskValue.substring(i,i+1);
			if (!this.isFixedCharacterMask(maskChar)) {
				rawValue += formatedValue.substring(i,i+1);
			}
		}
		
		return rawValue;
	}

	protected formatMaskedValue(maskValue: string, rawValue: string): string {

		let formatedValue : string = "";
		let nb = 0;

		for (let i = 0; i < maskValue.length; i++) {

			let maskChar = maskValue.substring(i,i+1);
			if (i-nb < rawValue.length){
				if (this.isFixedCharacterMask(maskChar)) {
					formatedValue+=maskChar;
					nb++;
				} else {
					formatedValue += rawValue.substring(i-nb,i-nb+1);
				}
			}
		}
		
		return formatedValue;
	}
}