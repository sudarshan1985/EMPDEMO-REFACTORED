import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Additional
import { CalendarModule, InputSwitchModule, SharedModule } from 'primeng/primeng';

// Components
import { BooleanCheckboxComponent } from './boolean-checkbox.component';
import { DynamicDatepickerComponent } from './dynamic-datepicker.component';
import { DynamicAutoCompleteComponent } from './dynamic-autocomplete.component';
import { DynamicRadioComponent } from './dynamic-radio.component';
import { DynamicSelectComponent } from './dynamic-select.component';
import { DynamicSwitchComponent } from './dynamic-switch.component';


import {
    MatInputModule,
    MatAutocompleteModule,
    MatToolbarModule,
  } from '@angular/material';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatInputModule,
        MatAutocompleteModule,
        MatToolbarModule,
        // Additional
        CalendarModule,
        InputSwitchModule,
        SharedModule
    ],
    declarations: [
        // Components
        BooleanCheckboxComponent,
        DynamicDatepickerComponent,
        DynamicAutoCompleteComponent, 
        DynamicRadioComponent,
        DynamicSelectComponent,
        DynamicSwitchComponent,
    ],
    exports: [
        CommonModule,
        FormsModule,
        // Additional
        CalendarModule,
        InputSwitchModule,
        // Components
        BooleanCheckboxComponent,
        DynamicDatepickerComponent,
        DynamicAutoCompleteComponent,
        DynamicRadioComponent,
        DynamicSelectComponent,
        DynamicSwitchComponent,
    ]
})
export class DynamicFieldCustomModule {}
