import { Component, ViewChild, ElementRef, Input } from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { NG_VALUE_ACCESSOR } from '@angular/forms';


import { CustomDynamicFieldComponent } from '../custom-dynamic-field.component';
import { Attributes } from '../../term/message';

export interface Option {
	label: string;
	value : string;
}

@Component({
    moduleId: module.id,
    selector: 'dynamic-autocomplete',
    template: `
	<input #input type="text" [class]="styleClass" [ngClass]="classes" matInput [formControl]="myControl" [matAutocomplete]="auto">
    <mat-autocomplete #auto="matAutocomplete">
      <mat-option *ngFor="let option of filteredOptions | async" [value]="option.value" >
        {{option.label}}
      </mat-option>
    </mat-autocomplete>
	`,
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: DynamicAutoCompleteComponent,
			multi: true
		},
	],

})


export class DynamicAutoCompleteComponent extends CustomDynamicFieldComponent {
	/* FIELDS ============================================================== */
	private _input: HTMLInputElement;

	classes: string[] = [];

	@Input() id: string; // inherited
	@Input() size: number; // inherited

	@Input() styleClass: any;
	@Input() options: Option[];

	@ViewChild('input') inputRef: ElementRef;

    /* CONSTRUCTORS ======================================================== */
    constructor() {
		super();
		this.registerOnChange(() => {
			this.computeAttributes();
			this.computeFocus();
		});
	}

	myControl = new FormControl();
 
	filteredOptions: Observable<Option[]>;

	ngOnInit() {
		this.filteredOptions = this.myControl.valueChanges
		.pipe(
			startWith(''),
			map(value => this._filter(value))
		);
		this._input = this.inputRef.nativeElement;
	}

	private _filter(value: string): Option[] {
		const filterValue = value.toLowerCase();
		if (this.myControl.value) {
			this.value = this.myControl.value as string;
		}
		return this.options.filter(option => option.label.toLowerCase().includes(filterValue));
	}



	private computeAttributes() {
		// Decode attributes
		let attributes: Attributes = this.data.attributes;
		if (!attributes) {
			// May happen due to SEND TEXT
			return;
		}

		// Determinate classes
		this.classes = [];
	
		if (attributes.color !== undefined) {
			this.classes.push(attributes.color.toLowerCase());
		}

		// Determinate consultation mode (readOnly)
		this.data.disabled =  attributes.protection === 'ASKIP';
		this.data.protected = attributes.protection === 'PROT';
	}

	private computeFocus() {
		if (this.data.initialCursor !== undefined && this.data.initialCursor) {
			setTimeout(() => {
				// Comment because focus expand the list
				//this._input.focus();
				console.log('Focus set on field ' + this.id);
			}, 0);
		}
	}


}
