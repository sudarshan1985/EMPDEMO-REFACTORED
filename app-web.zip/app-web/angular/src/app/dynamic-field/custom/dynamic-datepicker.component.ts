import { Component, Input, ViewEncapsulation } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as moment from 'moment';

//import moment = require('moment');

import { CustomDynamicFieldComponent } from '../custom-dynamic-field.component';

@Component({
    moduleId: module.id,
    selector: 'dynamic-datepicker',
    template: `
		<p-calendar [(ngModel)]="date" dateFormat="ddmmy" inputStyleClass="form-control"></p-calendar>
	`,
	styles: [ `
		.ui-calendar { width: 100%; }
	` ],
	encapsulation: ViewEncapsulation.None,
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: DynamicDatepickerComponent,
			multi: true
		},
	],
})
export class DynamicDatepickerComponent extends CustomDynamicFieldComponent {
	/* FIELDS ============================================================== */
	private _date: Date = null;

	@Input() id: string; // inherited
	@Input() size: number; // inherited

    /* CONSTRUCTORS ======================================================== */
    constructor() {
    	super();
		this.registerOnChange( () => {
			console.log('onChange( ' + this.value + ')');
			let value = this.value;
			if( value ) {
				let groups = value.match( /^([0-9]{2})([0-9]{2})([0-9]{2})$/ );
				if( groups ) {
					this._date = new Date( parseInt( groups[ 3 ] ), parseInt( groups[ 2 ] ), parseInt( groups[ 1 ] ) );
					return;
				}
			}
			this._date = null;
		} );
	}

	/* METHODS ============================================================= */
	public get date(): Date {
		return this._date;
	}

	public set date( date: Date ) {
		this._date = date;
		this.value = date ? moment( date ).format( 'DDMMYY' ) : this.defaultValue;
	}
}
