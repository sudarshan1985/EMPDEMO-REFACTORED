import { Component, Input, ViewChild, ElementRef, HostListener } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

import { Attributes } from '../term/message';
import { DynamicFieldComponent } from './dynamic-field.component';
import { AppService } from '../app.service';
import { TransactionService } from '../term/transaction.service';

function isDefinedAndDifferentOf(value: string, notExpected: string) {
	return value && (value !== notExpected);
}

const enum Action {
	Insert = 1,
	Suppress,
	Delete,
	Copy
}

@Component({
	moduleId: module.id,
	selector: 'dynamic-field',
	// Spaces are significant => all on one line, no space or break-line outer tag
	template: `<input #input [disabled]="data.disabled" [readonly]="data.protected" [style.text-align]="computeAlignement()"
		[attr.id]="id" [attr.name]="id" type={{inputType}} [attr.size]="size" [attr.maxlength]="size"
		[attr.mask]="mask" [attr.underline]="underline" 
		[style.width]="computeWidth()" [class]="styleClass" [ngClass]="computeClasses()"
		[(ngModel)]="data.value" 
		(keydown)="onKeyDown($event)" (keypress)="onKeyPress($event)"
		(input)="onInput()" (paste)="onPaste($event)"
		(focus)="onFocus($event)" (blur)="onBlur()" />`,
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: DefaultDynamicFieldComponent,
			multi: true
		},
	],
})
export class DefaultDynamicFieldComponent extends DynamicFieldComponent {
	/* FIELDS ============================================================== */
	private _input: HTMLInputElement;
	private parentDiv;

	private _focused = false;
	private _insertMode = false;
	private _useCombinationsAttributes = false;

	@Input() id: string; // inherited
	@Input() size: number = 0; // inherited
	@Input() styleClass: string;
	@Input() inputType: string = 'text';
	@Input() isLCAllowed: Boolean;
	@Input() focused: Boolean;
	@Input() line: number;
	@Input() column: number;

	@ViewChild('input') inputRef: ElementRef;

	/* CONSTRUCTORS ======================================================== */
	constructor(appService: AppService, public transactionService: TransactionService, elRef: ElementRef) {
		super();
		this.registerOnChange(() => {
			this.computeAttributes();
			this.computeFocus();
		});
		// Parent div element (typically contains lgr_ / lgo_ classes)
		if(elRef.nativeElement.parentElement != null && elRef.nativeElement.parentElement.tagName == 'DIV'){
			this.parentDiv = elRef.nativeElement.parentElement;
		}
		this._insertMode = appService.insertMode;
		appService.registerOnInsertModeChange((insertMode) => this._insertMode = insertMode);
		this._useCombinationsAttributes = transactionService.is5250();
	}

	/* METHODS ============================================================= */
	ngOnInit(): void {
		super.ngOnInit();
		this._input = this.inputRef.nativeElement;
	}

	/* Compute ------------------------------------------------------------- */
	computeWidth(): string {
		// Needed since the "size"" attribute of input is not precise enough
		return this.computeFontWidth(this._input) * this.size + 'px';
	}

	private computeFontWidth(element: any): number {
		if (window['CACHED_FONT_WIDTH'] === undefined) {
			// Compute and cache font width, using an hidden canvas
			var st: CSSStyleDeclaration = window.getComputedStyle(element);

			// For firefox compatibility: do not use the "font" shorthand property of CSSStyleDeclaration
			var font: string = st.fontStyle + ' ' + st.fontVariant + ' ' + st.fontWeight + ' ' + st.fontSize + '/' + st.lineHeight + ' ' + st.fontFamily;

			var canvas = document.createElement('canvas');
			var context: CanvasRenderingContext2D = canvas.getContext('2d');
			context.font = font;
			window['CACHED_FONT_WIDTH'] = Math.ceil(context.measureText('W').width)
		}

		return window['CACHED_FONT_WIDTH'];
	}

	computeClasses(): string[] {
		// Decode attributes
		let attributes: Attributes = this.data.attributes;
		if (!attributes) {
			// May happen due to SEND TEXT
			return;
		}
		
		// Determinate classes
		let classes = [];
		if (isDefinedAndDifferentOf(attributes.intensity, 'NORM')) {
			classes.push(attributes.intensity.toLowerCase());
		}
		if (attributes.color !== undefined) {
			classes.push(attributes.color.toLowerCase());
		}
		if (isDefinedAndDifferentOf(attributes.highlight, 'OFF')) {
			classes.push(attributes.highlight.toLowerCase());
		}

		// Add hidden class to parent div if needed
		if(this.parentDiv) {
			if (classes.indexOf('hidden') >= 0) {
				this.parentDiv.classList.add('hidden');
			} else {
				this.parentDiv.classList.remove('hidden');
			}
		}

		return classes;
	}

	private computeAttributes() {
		// Decode attributes
		let attributes: Attributes = this.data.attributes;
		if (!attributes) {
			// May happen due to SEND TEXT
			return;
		}
		
		if(attributes !== undefined && attributes !== null 
			&& this.inputType !== undefined && this.inputType === 'password'){
			attributes.isPassword = true;
		}
		
		if (this._useCombinationsAttributes) {
			// Set combinations attributes
			this.setCombinationsAttributes(attributes);
		}
		
		if (attributes.isPassword) {
			this.inputType = 'password'
		}

		// Determinate classes
		this.computeClasses();

		if (attributes.mask !== undefined) {
			this.mask = attributes.mask;
		}
		
		if (attributes.underline !== undefined) {
			this.underline = attributes.underline;
		}

		// Determinate consultation mode (readOnly)
		this.data.disabled =  attributes.protection === 'ASKIP';
		this.data.protected = attributes.protection === 'PROT';
	}

	/*
	 * Set good color with attributes
	 * See https://www.ibm.com/support/knowledgecenter/ssw_ibm_i_72/rzakc/rzakcmstdfcolor.htm
	 * 
	 */
	private setCombinationsAttributes(attributes: Attributes): void {
		// In some combinations of COLOR and DSPATR, both keywords have effect.
		// In some combinations of the COLOR and DSPATR keywords, some of the parameter values are ignored.
		let color: string = attributes.color;
		let highlight: string = attributes.highlight;
		let intensity: string = attributes.intensity;
		let protection: string = attributes.protection;
		let password = intensity === 'PWD';
		if (password) {
			attributes.isPassword = true;
			intensity = 'NORM';
			if (!color) {
				color = 'DEFAULT';
			}
		} else {
		// ND (nondisplay) - All colors are ignored
		if (intensity === 'DRK') {
			// Change dark to hidden to remove field space on screen
			intensity = 'HIDDEN'; 
			color = '';
		} else {
			if (color) {
				// HI is ignored
				intensity = '';
				// TODO CS is ignored
				// The only color that can blink is red.
				if (color !== 'RED' && highlight === 'BLINK') {
					highlight = '';
				}
			} else {
				if (attributes.columnSeparator) {
					if (intensity === 'high') {
						if (highlight === 'BLINK') {
							color = 'BLUE';
						} else {
							color = 'YELLOW';
						}
					} else {
						if (highlight === 'BLINK') {
							color = 'PINK';
						} else {
							color = 'TURQUOISE';
						}
					}
				} else {
					if (intensity === 'high') {
						if (highlight === 'BLINK') {
							color = 'RED';
						} else {
							color = 'WHITE';
						}
					} else {
						if (highlight === 'BLINK') {
							color = 'RED';
						} else {
							color = 'DEFAULT';
						}
					}
				}
			}
			// Set empty attributes with default value
			if (!color) {
				color = 'DEFAULT';
			}
			if (!intensity) {
				intensity = 'NORM';
			}
		}
		}
		if (!protection) {
			protection = 'ASKIP';
		}
		attributes.color = color;
		attributes.highlight = highlight;
		attributes.intensity = intensity;
		attributes.protection = protection;
	}

	private computeFocus() {
		if (this.focused !== null && this.focused) {
			setTimeout(() => {
				this._input.focus();
			}, 0);			
		} else if (this.data.initialCursor !== undefined && this.data.initialCursor) {
			setTimeout(() => {
				this._input.focus();
				console.log('Focus set on field ' + this.id);
			}, 0);
		} else if (this.data.cursorLine !== undefined && this.data.cursorColumn !== undefined) {
			if (this.line == this.data.cursorLine && (this.column + 1) == this.data.cursorColumn) {
				setTimeout(() => {
					this._input.focus();
				}, 0);
			}
		}
	}

	/* Events -------------------------------------------------------------- */
	/* Focus */
	public onFocus(event: FocusEvent) {
		this._focused = true;
		if (!this._insertMode) {
			this._input.selectionStart = 0;
			this._input.selectionEnd = this._input.value.length;
			return;
		}

		let cursor = this._input['_cursor'];
		if (!cursor && event.relatedTarget) {
			cursor = 0;
		}
		this._input['_cursor'] = undefined;

		setTimeout(() => {
			if (cursor !== undefined) {
				this._input.selectionStart = this._input.selectionEnd = cursor;
				return;
			}

			let start = this._input.selectionStart;
			if ((start === this._input.selectionEnd) && (start === this.size)) {
				this._input.selectionStart = this._input.selectionEnd = 0;
			}
		});
	}

	public onBlur() {
		this._focused = false;
	}

	/* Keyboard */
	public onKeyDown(event: KeyboardEvent) {
		let start = this._input.selectionStart;
		let end = this._input.selectionEnd;
		if (event.key === 'Backspace') {

			let pair = this._manageFixCharacterFromMask(Action.Suppress, start, end);
			end = pair.end;
			start = pair.start;

			if (start === end && start === 0) {
				// Back tab
				this._nextInput(-1);
				return false;
			} else if (this._insertMode) {
				// Remove character and set cursor to the start
				start = this._insertValue((start === end) ? --start : start, end, '').start;
				this._updateCursor(start);
				return false;
			}
		} else if (event.key === 'Delete') {
			if (this._insertMode) {
				if (start === end && start === this.size) {
					// Forward tab
					this._nextInput(+1);
				} else {
					// Remove character and set cursor to the end
					end = this._insertValue(this._input.selectionStart, end, '').end;
					if (end === this.size) {
						// Forward tab
						this._nextInput(+1);
					} else {
						this._updateCursor(end);
					}
					
				}
				return false;
			} else {
				this._manageFixCharacterFromMask(Action.Delete, start, end);
				this._updateCursor(end);
				return false;
			}
			
		} else if (event.key === 'ArrowLeft') {
			// Back tab
			if (start === end && start === 0) {
				this._nextInput(-1);
				return false;
			}
		} else if (event.key === 'ArrowRight') {
			// Forward tab
			if (start === end && start === this.size) {
				this._nextInput(+1);
				return false;
			}
		} else if (event.key === 'Tab' && this._insertMode) {
			// Forward (or back if shift down) tab
			this._nextInput(event.shiftKey ? -1 : +1);
			return false;
		}
	}

	public onKeyPress(event: KeyboardEvent) {
		let start = this._input.selectionStart;
		let end = this._input.selectionEnd;
		if (!this._insertMode) {
			// Add fixed character from mask value
			let pair = this._manageFixCharacterFromMask(Action.Insert, start, end, event.key);
			// Selection is only character : it has been replaced by a character from mask and input is filled
			if (pair.start == start + 1 && pair.end == this.size) {
				return false;
			}
			return;
		}
		
		if (start < this.size) {
			end = this._insertValue(start, end, event.key).end;
			if (end === this.size) {
				// Forward tab
				this._nextInput(+1);
			} else {
				this._updateCursor(end);
			}
			return false;
		}
	}

	/* Changes */
	public onInput() {
		if (this._insertMode) {
			this._formatValue();
		}
        if(this.transactionService.is5250() && !this.isLCAllowed) {
			this.data.value = this.data.value.toUpperCase();
        }
		// Auto-tab if cursor on the last character
		if (this._input.selectionStart === this.size) {
			this._nextInput(+1);
		}
	}

	public onPaste(event: ClipboardEvent) {

		let start = this._input.selectionStart;
		let end = this._input.selectionEnd;
		let value: string = event.clipboardData.getData('text');
		if (!this._insertMode) {
			this._manageFixCharacterFromMask(Action.Copy, start, end, value);
			return;
		}



		if ((end - start) < value.length) {
			// Update selection
			end = start + value.length;
			if (end > this.size) {
				// Too long value (cut outside)
				value = value.substring(0, value.length - (end - this.size));
				end = this.size;
			}
		}

		end = this._insertValue(start, end, value).end;
		if (end === this.size) {
			// Forward tab
			this._nextInput(+1);
		} else {
			this._updateCursor(end);
		}
		return false;
	}

	/* Navigation ---------------------------------------------------------- */
	private _nextInput(step: number): void {
		let inputs: NodeListOf<Element> = document.querySelectorAll('dynamic-field > input:not([type=hidden]):not(:disabled):not(:read-only)');
		for (let i = 0; i < inputs.length; i++) {
			if (inputs.item(i) === this._input) {
				let j = i + step;
				if ((j >= 0) && (j < inputs.length)) {
					let input = <HTMLInputElement>inputs[j];
					if (this._insertMode) {
						input['_cursor'] = (step > 0) ? 0 : input.value.length;
					}
					setTimeout(() => input.focus(), 0);
					break;
				}
			}
		}
	}

	private _updateCursor(cursor: number) {
		setTimeout(() => {
			this._input.selectionStart = this._input.selectionEnd = cursor;
		}, 0);
	}

	/* Value --------------------------------------------------------------- */
	private _insertValue(start: number, end: number, value: string): { start: number, end: number } {
		// Check cursor
		if (start === end) {
			end++;
		} else if (end < start) {
			return this._insertValue(end, start, value);
		}

		// Check value
		let size = (end - start);
		if (value.length < size) {
			value += this.defaultValue.substr(start, size - value.length);
		}

		// Insert value
		this.data.value = this.data.value.substring(0, start)
			+ value
			+ this.data.value.substring(end);
		return { start: start, end: end };
	}

	private isAllowed(): boolean {
		return !this._input.getAttribute("mask")
	}

	private _manageFixCharacterFromMask(action: Action, start: number, end: number, value?: string): {start: number, end: number } {
		
		let maskValue = this._input.getAttribute("mask");

		if (!!maskValue){

			if (action === Action.Suppress) {
				if(start < maskValue.length) {
					if (start-2 > 0) {
						let maskChar = maskValue.substring(start-2,start-1);
						if (this.isFixedCharacterMask(maskChar)) {
							start = start - 1;
							end = end - 1;
							this.data.value = this.data.value.substring(0, start)
						}
					} 
				}
			} else if (action === Action.Insert) {
				if(start < maskValue.length) {
					let maskChar = maskValue.substring(start,start+1);
					if (this.isFixedCharacterMask(maskChar)) {
						start++;
						end = this._insertValue(start, end, maskChar).end;
					} 
				}
/*
				let rawValue = this.getRawValue(maskValue, this.data.value);
				let startRaw = this.getOffSetIndexRawValue(maskValue, start);
				rawValue = rawValue.substring(0, startRaw) + value + rawValue.substring(startRaw+1, rawValue.length);
				this.data.value = this.formatMaskedValue(maskValue, rawValue);
				end++;
*/
			}  else if (action === Action.Delete) {
				
				let rawValue = this.getRawValue(maskValue, this.data.value);
				let startRaw = this.getOffSetIndexRawValue(maskValue, start);
				rawValue = rawValue.substring(0, startRaw) + rawValue.substring(startRaw+1, rawValue.length);
				this.data.value = this.formatMaskedValue(maskValue, rawValue);

			} else if (action === Action.Copy) {
				
				this.data.value = this.formatMaskedValue(maskValue, value);
			}
		}

		return { start: start ,end: end };
	}
}
