import { EmpmsetComponentsMap } from "./empmset/";
import { UtilityComponentsMap, UtilitySubComponentsMap } from "./utility/";

export const mapSubComponents = {
    ...UtilitySubComponentsMap
};

export const mapComponents = {
    ...EmpmsetComponentsMap,
    ...UtilityComponentsMap
};