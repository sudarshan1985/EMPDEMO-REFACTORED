
import { Component } from '@angular/core';
import { Overlay } from "./../commonMap/overlay";

@Component({
    moduleId: module.id,
    selector: 'standard-messageline',
    templateUrl: './standard-messageline.component.html'
})
export class StandardMessageLineComponent extends Overlay {
    messageline: any = {};
    
    public FIELDS: string[] = ['messageline']
}


