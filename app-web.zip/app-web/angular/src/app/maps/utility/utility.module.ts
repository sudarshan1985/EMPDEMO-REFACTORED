import { NgModule } from '@angular/core';
import { EndMessageComponent } from './end-message.component';
import { EndMessageSubComponent } from './end-message-sub.component';
import { RawtextComponent } from './rawtext.component'
import { StandardMessageLineComponent } from './standard-messageline.component';
import { SharedModule } from '../../shared.module';

@NgModule({
    imports: [SharedModule],
    exports: [],
    declarations: [EndMessageComponent, EndMessageSubComponent, 
        RawtextComponent, StandardMessageLineComponent]
})
export class UtilityModule { }

