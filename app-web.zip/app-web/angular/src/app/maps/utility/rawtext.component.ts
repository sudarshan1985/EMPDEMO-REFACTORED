import { Component } from '@angular/core';
import { Overlay } from "./../commonMap/overlay";

@Component({
    moduleId: module.id,
    selector: 'rawtext',
    templateUrl: './rawtext.component.html'
})
export class RawtextComponent extends Overlay {
    text: any = {};

    public FIELDS: string[] = ['text'];
}
