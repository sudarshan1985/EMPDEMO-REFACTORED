import { EndMessageComponent } from './end-message.component';
import { EndMessageSubComponent } from './end-message-sub.component';
import { StandardMessageLineComponent } from './standard-messageline.component';
import { RawtextComponent } from './rawtext.component';

export { UtilityModule } from './utility.module';

export const UtilitySubComponentsMap = {
    "end-message": EndMessageSubComponent
};

export const UtilityComponentsMap = {
    "standard-messageline": StandardMessageLineComponent,
    "end-message": EndMessageComponent,
    "rawtext":RawtextComponent
};

export const UtilityComponents = [
    EndMessageComponent, 
    EndMessageSubComponent, 
    RawtextComponent, 
    StandardMessageLineComponent 
];