import { Component } from '@angular/core';
import { Overlay } from "./../commonMap/overlay";

@Component({
    moduleId: module.id,
    selector: 'empmset-empmap',
    templateUrl: './empmset-empmap.component.html'
})
export class EmpmsetEmpmapComponent extends Overlay {
    tranid: any = {'value': 'XXXX'};
    date: any = {'value': '__________'};
    time: any = {'value': '__________'};
    empno: any = {'value': '______'};
    efname: any = {'value': '__________'};
    elname: any = {'value': '__________'};
    eaddr: any = {'value': '__________'};
    ephno: any = {'value': '__________'};
    message: any = {};
    dummy: any = {};

    public FIELDS: string[] = ['tranid', 'date', 'time', 'empno', 'efname', 'elname', 'eaddr', 'ephno', 'message', 'dummy'];
    public LINES: number[] = [1, 2, 3, 5, 22, 7, 23, 24, 9, 11, 13];
}
