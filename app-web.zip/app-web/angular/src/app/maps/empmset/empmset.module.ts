import { NgModule } from '@angular/core';
import { EmpmsetEmpmapComponent } from './empmset-empmap.component';
import { SharedModule } from './../../shared.module';

@NgModule({
    imports: [SharedModule],
    exports: [],
    declarations: [EmpmsetEmpmapComponent]
})
export class EmpmsetModule { }

