import { EmpmsetEmpmapComponent } from './empmset-empmap.component';

export { EmpmsetModule } from './empmset.module';

export const EmpmsetSubComponentsMap = {
	
};

export const EmpmsetComponentsMap = {
	"empmset-empmap": EmpmsetEmpmapComponent
};

export const EmpmsetComponents = [
	EmpmsetEmpmapComponent
];

