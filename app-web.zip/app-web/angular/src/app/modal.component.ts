import { Component,  Input, SystemJsNgModuleLoader, Compiler, ComponentFactoryResolver } from '@angular/core';
import { NgModule } from '@angular/core';
import { ModalService, MODALSERVICE } from './modal.service';
import { Subscription } from 'rxjs';
import { WindowComponents, BackendMessage } from './term/message';
import { AbstTermComponent } from './abs-term.component';
import { mapSubComponents } from './maps/mapComponents';
import { TransactionService } from './term/transaction.service';
import { ActivatedRoute } from '@angular/router';
import { TermService } from './term/term.service';
import { TestingService } from './term/testing.service';
import { CommonsModule } from './commons.module';
import { AppService } from './app.service';

const KEY_ESC = 27;
/** Constante to retrieve instead */
// lrg height css
const baseHeight = 1.4;
declare var $: any;

@Component({
    selector: 'modal-window',
    template: `
    <div [id]="name" class="modal" tabindex="-1" role="dialog">
    <div [ngClass]="modalClass()" style="position: absolute">
        <div class="modal-content" [ngStyle]="positionStyle()" >                
                <div>
                    <div *ngIf="hasBorderTop()" [ngStyle]="titleTopStyle()">
                    {{titleTop}}
                    </div> 
                        <div #dynamicTarget></div>
                    <div *ngIf="hasBorderBottom()" [ngStyle]="titleBottomStyle()">
                    {{titleBottom}}
                    </div> 
                </div> 
        </div>
    </div>
</div>
        `
})

/** Component Modal */
export class ModalComponent extends AbstTermComponent {

    constructor(
        modalService: ModalService,
        transactionService: TransactionService,
        route: ActivatedRoute,
        loader: SystemJsNgModuleLoader,
        compiler: Compiler,
        service: TermService,
        componentFactoryResolver: ComponentFactoryResolver,
        appService: AppService,
        testingService: TestingService
    ) {
        super(modalService, transactionService, route, loader, compiler, service, componentFactoryResolver, appService, testingService);
    }

    @Input() name: string;

    // Position : upper-left corner 
	/** The left position. */
    private positionLeft: number;
	/** The top position. */
	private positionTop: number;
	
	/** The cursor position from which displaying modal. Actually not exploited.*/
	private cursorPosition: boolean;
	
	/** The size's height. Actually not exploited, modal height is set by the content */
	private height: number;
	
	/** The size's width. */
    private width: number;

    /** Color border */
    public borderColor: string;

    /** border */
    public border : boolean;

    /** Title */
	public titleTop: string;	
	public titleBottom: string;
	public titleColorTop: string;
	public titleColorBottom: string;	
	public titleAlignTop: string;
	public titleAlignBottom: string;
	public borderTop: string;
	public borderBottom: string;

    private subscription: Subscription;

    getMapComponent(mapName: string) {
        return mapSubComponents[mapName];
    }

    getIdAnchor() : any  {
        return $("#" + this.name).children().children().children();
    }

    protected haveToChangeTargetAccessibility(): boolean {
        return true;
    }

    decodeFieldsSubComponent(): boolean {
        return true;
    }

    getName(): String {
        return this.name;
    }

    postAction() {
         this._hideDialog();
    }
    
    public onReceivedMessage(backendMessage: BackendMessage): void {
        // Destroy current modal component
        this.getComponent(this.name).destroy();
        // Transfer to main component receiver
        this.getParent().onReceivedMessage(backendMessage);
    }

    private _defaults = {
        title: 'Confirmation',
        message: 'Do you want to cancel your changes?',
        cancelText: 'Cancel',
        okText: 'Yes'
    };

    activate(): Promise<boolean> {
        console.log('Displays modal ' + this.name );
        let promise = new Promise<boolean>(resolve => {
            this._show(resolve);
        });

        return promise;
    }

    private _show(resolve: (boolean) => any) {
        document.onkeyup = null;
        setTimeout(() => $('#' + this.name).modal('show'), 50);
        this.modalService.pushModal(this.name);
        document.onkeyup = (e: any) => {
            if (e.which == KEY_ESC) {
                this._hideDialog();
                return resolve(false);
            }
        };
    }

    private _hideDialog() {
        $('#' + this.name).modal('hide');
        this.modalService.popModal(this.name);
    }

    ngOnInit(): any {
        this.subscription = this.modalService.activeModal(this.name).subscribe( ({message, parentComponent}) => {
            this.activate();
            this.setParent(parentComponent);
            this.processLogicalMessage(message);
            this.mapWindowAttributes(message as WindowComponents);
        });
    }

    ngOnDestroy(): void {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    private mapWindowAttributes(message: WindowComponents) {

        message.maps.forEach(windowMap => {
            if(windowMap.component == "end-message"){
                this.borderColor = "#C00000";
                this.positionLeft = this.modalService.getDefaultPosLeft();
                this.positionTop = this.modalService.getDefaultPosTop();
                this.height = this.modalService.getDefaultHeight();
                this.width = this.modalService.getDefaultWidth();
                this.cursorPosition = false;
            } else {
                if (windowMap.borderColor) {
                    this.borderColor = windowMap.borderColor;
                }

                if (windowMap.border) {
                    this.border = windowMap.border;
                }

                if (windowMap.positionLeft) {
                    this.positionLeft = windowMap.positionLeft;
                }

                if (windowMap.positionTop) {
                    this.positionTop = windowMap.positionTop;
                }

                if (windowMap.height) {
                    this.height = windowMap.height;
                }

                if (windowMap.width) {
                    this.width = windowMap.width;
                }

                if (windowMap.cursorPosition) {
                    this.cursorPosition = windowMap.cursorPosition;
                }
                
                if (windowMap.titleTop) {
                    this.titleTop = windowMap.titleTop;
                }

                if (windowMap.titleBottom) {
                    this.titleBottom = windowMap.titleBottom;
                }
                
                if (windowMap.titleColorTop) {
                    this.titleColorTop = windowMap.titleColorTop;
                }
 
                 if (windowMap.titleColorBottom) {
                    this.titleColorBottom = windowMap.titleColorBottom;
                }

                if (windowMap.titleAlignTop) {
                    this.titleAlignTop = windowMap.titleAlignTop;
                }
                
                if (windowMap.titleAlignBottom) {
                    this.titleAlignBottom = windowMap.titleAlignBottom;
                }               
 
                if (windowMap.borderTop) {
                    this.borderTop = windowMap.borderTop;
                } 
                
                if (windowMap.borderBottom) {
                    this.borderBottom = windowMap.borderBottom;
                } 
            }
        });
    }

    /** complete style with a separator if style is not empty */
    addTextToStyle(style:string, text:string):string {
        if (style.length > 1) {
            style += ',';
        }
        style += text;
        return style;

    }

    modalClass(){
        let text = "modal-dialog";
        if(this.isScreenExtended()){
            text += " A7";
        }
        return text;
    }

    /**  Set position as upper-left corner */
    positionStyle() {
        // Screen width
        let sizePanel = this.isScreenExtended() ? 132 : 80;
        // Line Height
        let lineHeigth = 1.25;

        let style = "{";

        if (this.positionLeft && this.positionTop) {
            let newLeftPosition = (100*this.positionLeft)/sizePanel;
            style += '"left": "' + newLeftPosition + '%"';

            if(this.hasBorderTop()){
                style += ',"top": "' + (this.positionTop * lineHeigth - baseHeight) + 'em"';
            } else {
                style += ',"top": "' + this.positionTop * lineHeigth + 'em"';
            }
        }

        if (this.width && this.height) {
            let width = (100*this.width)/sizePanel;
            style = this.addTextToStyle(style, '"width":"'+ width + '%"');

            let height = (this.height *  baseHeight);
            if (this.border) {
                height += 2*baseHeight;
                style += ',"border-top": "none"';
            } else {
                if (this.hasBorderTop() ) {
                    height += baseHeight;
                }
                if (this.hasBorderBottom()) {
                    height += baseHeight;
                }
            }
       
            style += ',"height":"'+ height + 'em"'; 
        }

        if (this.borderColor) {
			// Set the border color
            style += ',"border-color": "' + this.borderColor + '"';
        }
        style += "}";

        return JSON.parse(style);
    }

    hasBorderTop(): boolean {
        if (this.border) {
            return true;
        } else {
            // title is defined
            if (this.titleTop) {
                return true;
            } else {
                if (this.borderTop) {
                    return true;
                }
            }
        }
        return false;
    }

    hasBorderBottom() {
        if (this.border) {
            return true;
        } else {
            // title is defined
            if (this.titleBottom) {
                return true;
            } else {
                if (this.borderBottom) {
                    return true;
                }
            }
        }
        return false;
    }

    /**  Style of the title in the top of the border */
    titleTopStyle() {

        let style = "{";
        style += '"position": "absolute",';
        style += '"width": "100%",';
        style += '"height": "' + baseHeight + 'em",';
        
        if (this.borderColor) {
            style += '"background-color": "' + this.borderColor + '"';
        }

        if (this.titleAlignTop) {
            style += ',"text-align": "' + this.titleAlignTop + '"';
        } else {
            style += ',"text-align": "center"'; 
        }
        if (this.titleColorTop) {
            style += ',"color": "' + this.titleColorTop + '"';
        }
        style += "}";
        return JSON.parse(style);
    }

    /**  Style of the title in the bottom of the border */
    titleBottomStyle() {
        let style = "{";
        style += '"position": "absolute",';
        style += '"width": "100%",';
        style += '"height": "' + baseHeight + 'em",';

        if (this.borderColor) {
            style += '"background-color": "' + this.borderColor + '"';
        }

        if (this.titleAlignBottom) {
            style += ',"text-align": "' + this.titleAlignBottom + '"';
        }
        if (this.titleColorBottom) {
            style += ',"color": "' + this.titleColorTop + '"';
        }
        if (this.positionLeft && this.positionTop) {
            let height = (this.height *  baseHeight);

            if (this.border || this.hasBorderBottom()) {
                height += baseHeight;
            }
      
            style += ',"top": "' + height + 'em"';
        }
        style += "}";
        return JSON.parse(style);
    }
    
}

@NgModule({
    imports: [
        CommonsModule
    ],
    declarations: [ModalComponent],
    providers: [MODALSERVICE],
    exports: [ModalComponent]
})
export class ModalModule {

}
