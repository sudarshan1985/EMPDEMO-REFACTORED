import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgxMaskModule } from 'ngx-mask';


@NgModule({
    imports: [
		CommonModule,
        FormsModule,
        NgxMaskModule.forRoot()
	],

    exports: [
        CommonModule,
        FormsModule,
        NgxMaskModule
    ]
})
export class CommonsModule { }
