import { Component, OnInit, OnDestroy, HostListener, AfterViewChecked, ComponentFactoryResolver } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import * as $ from 'jquery';

// Component injection imports
import { ViewContainerRef, ViewChild, ComponentRef } from '@angular/core';
import { SystemJsNgModuleLoader, NgModuleFactory, Compiler, Type, NgModuleRef, ComponentFactory } from '@angular/core';

import 'rxjs/add/operator/switchMap';

import { BackendMessage, LogicalMessage, Map, WindowMap, Field } from './term/message';
import { Paging } from './table/table.component';
import { AddComponents, RebindComponents, RemoveAllComponents, WindowComponents, SetCursorPosition } from './term/message';
import { TransactionService } from './term/transaction.service';
import { Data } from './term/term.model';
import { TermService } from './term/term.service';
import { TestingService } from './term/testing.service';
import { AppService } from './app.service';

import { AppConfigurationMessage } from './configuration-message.module';
import { ModalService } from './modal.service';

// Component injection imports

/** Simplify template expression */
class FactoryTuple {
    constructor(
        public modFac: NgModuleFactory<any>,
        public cmpFactory: ComponentFactory<any>,
        public componentName: string) { }
}

/** Abstract business component receiving, displaying and sending data */
export abstract class AbstTermComponent implements OnInit, OnDestroy, AfterViewChecked {

    // Component injection location
    @ViewChild('dynamicTarget', { read: ViewContainerRef })
    private dynamicTarget : ViewContainerRef;

    // Keep track of injected component(s)
    private injectedComponents: ComponentRef<any>[] = [];
    private injectedModalComponents: ComponentRef<any>[] = [];

    // Keep track of injected component(s), by name
    private componentsByName: { [key: string]: ComponentRef<any> } = {}
    private modalComponentsByName: { [key: string]: ComponentRef<any> } = {}
    private subComponentsByName: { [key: string]: any } = {}

    // Keep track of injected fields(s), by position
    private fieldsByPosition: { [key: number]: Data } = {}

    // Keep track of message treated
    private messages: LogicalMessage[] = []

    // The next transaction to run from this terminal (CICS "TRANSID" parameter)
    protected nextTransactionId: string;

    // Temporary; remove when the new style will be validated (V7-316)
    useModernLegacyStyle: boolean;

    // A message to display in the page footer
    private footerMessage: string;

    // Used by Setup menu. Enforce "Fixed Width" as the defaut setup
    private containerClasses = ['container'];

	private heightClasses = ['rdmq_height'];
	
	// Enforce "Fixed Width" as the default setup
    private widthMode: number = 2;
    private widthClasses = ['', 'rd_fixed_width', 'rd_full_width'];
    private widthClassesA7 = ['', 'rd_fixed_width_A7', 'rd_full_width'];
    private isExtended: boolean = false;

    /** The global configuration */
    public configuration: AppConfigurationMessage;

    /** Current year */
    public currentYear:number;

    /** Parent component */
    private parentComponent: AbstTermComponent;

    // Spinning indicator
    public static isSpinning: boolean = false;
    

    constructor(
        public modalService: ModalService,
        protected transactionService: TransactionService,
        private route: ActivatedRoute,
        private loader: SystemJsNgModuleLoader,
        private compiler: Compiler,
        private service: TermService,
        private componentFactoryResolver: ComponentFactoryResolver,
        private appService: AppService,
        private testingService: TestingService
    ) {
        service.onReceiveMessageToTerm = this.onReceivedMessage.bind(this);
        this.configuration = transactionService.configuration;
        this.currentYear = Date.now();
        console.log('useModernLegacyStyle: ' + this.useModernLegacyStyle);
   
    }

    
    abstract getMapComponent(mapName : string): any;
    abstract getIdAnchor(): any;
    abstract decodeFieldsSubComponent(): boolean;
    abstract getName(): String;
    
    protected postAction() {
        // Do Nothing
    }

    getComponent(name : string) {
        return this.componentsByName[name]
    }
    
    getModal(name : string) {
        return this.modalComponentsByName[name]
    }

    getFieldByPosition(position : number) {
        return this.fieldsByPosition[position]
    }

    setParent(parent: AbstTermComponent) {
        if (parent !== this) {
            this.parentComponent = parent;
        }
    }

    getParent(): AbstTermComponent {
        return this.parentComponent
    }

    ngOnInit(): void {
        let toRun = (params: Params) => this.onInvoke(params);
        let observable = this.route.params.switchMap(toRun);
        observable.subscribe((message: BackendMessage) => this.onReceivedMessage(message));
    }

    ngOnDestroy(): void {
        this.removeAnyExistingComponent();
    }


    public ngAfterViewChecked(): void {

        // Change DOM pointer-events attribute value to enable targetting.
        if (this.haveToChangeTargetAccessibility()) {

            // Disable pointer-event on all 
            this.getIdAnchor().attr("style", "pointer-events: none");

            // Keep accessible as target usefull fields
            let msgs : any[] = [];
            let numberLine : number = 0;
            this.getIdAnchor().children().each(
                function(index, values) {
                    msgs.push(values);
                    numberLine = Math.max(numberLine, $(values).children().children().length);
                }
            )

            // For each line
            for (let i = 0; i<numberLine; i++) {

                let retainDivLine;
                for (let j = 0; j<msgs.length; j++) {
                    let divLine = $(msgs[j]).children().children()[i];
                    if ($(divLine).children().filter(
                        function(index,value) {
                            return !value.classList.contains("lgr_00")
                        }
                    ).length > 0) {
                        retainDivLine = divLine;
                    }
                }


                // Set the last no empty div line attribute pointer-events value to visible
                if (retainDivLine != null) {
                    $(retainDivLine).attr("style", "pointer-events: visible");
                }
            }
        } else {
            // Re-establish default behaviour
            this.getIdAnchor().removeAttr("style");
        }
 
    }

    // Check if condition have to be changed to access target 
    protected haveToChangeTargetAccessibility(): boolean {

        // If there are several message and are in absolute position
        if (this.getIdAnchor().children().length > 1 && this.getIdAnchor().children().children().filter(
            function(index, value) {
                return $(value).css("position") === "absolute"
            }
        ).length > 0 ) {
            return true;
        }

        return false;
    }

    private toggleOverwriteMode(): void {
        this.appService.updateInsertMode();
    }

    protected changeSetup(widthMode: number): void {
        this.widthMode = widthMode;
    	this.containerClasses = ['container'];
    	if(widthMode >= 1 && widthMode <= 3){
    		this.containerClasses.push(!this.isExtended ? this.widthClasses[widthMode - 1] : this.widthClassesA7[widthMode - 1]);
		}
    }
    
    protected isScreenExtended(){
        if(this.parentComponent !== undefined){
            return this.parentComponent.isScreenExtended();
        }
        return this.isExtended;
    }

    private changeTheme(event: any): void {
        // Set the class of "body" to the one defined by the data-csw attribute
        let target = (<Element>event.target);
        let theme = target.getAttribute('data-csw');
        document.body.className = theme;
    }

    private onInvoke(params: Params): Promise<BackendMessage> {
        const startMessage: any = { 'resetTransactionData': true };

        const transid: string = params['transid'];
        if (transid.toLowerCase().startsWith('/testmap ')) {
            const args = transid.substring(transid.indexOf(' ') + 1);
            return Promise.resolve(this.testingService.buildTestMessage(args));
        }

        return this.transactionService.runTransaction(transid, startMessage);
    }

    public onReceivedMessage(backendMessage: BackendMessage): void {
        console.log('JSON message received from backend', backendMessage)

        AbstTermComponent.isSpinning = false;

        if (backendMessage.error !== undefined) {
            console.log('An error occured on backend: ' + backendMessage.error);
            this.setFooterMessage(backendMessage.error);
            return;
        }

        this.nextTransactionId = backendMessage.nextTransID;

        if (this.configuration.verbose) {
            this.setFooterMessage(backendMessage.serverDescription);
        } else {
        	// Remove potential obsolete error message
            this.setFooterMessage('');
        }

        if (backendMessage.messages == undefined || backendMessage.messages.length == 0) {
            console.log('No backend messages to process');
        } else {
            // Ensure each message is totally processed before the next one is (V7-3021)
            this.processSequentially(backendMessage.messages, 0);
        }
    }

    /** Set the footer message, or clear it is string is empty/undefined */
    private setFooterMessage(message: string):void {
        if (message == undefined) {
            message = '';
        }

        // Flashing footer if message has changed
        if (message !== '' && message != this.footerMessage) {
            this.animate();
        }

        this.footerMessage = message;
    }

    /** Active footer animation */
    private animate():void {
        $("#idFooter").removeClass("run-animation");
        setTimeout(() => {
            $("#idFooter").addClass("run-animation");
        }, 10);
    }

    /** Process logical messages sequentially (only one usually, but see V7-145) */
    private processSequentially(toProcess: LogicalMessage[], idx: number): void {
        if (idx >= toProcess.length) {
            return;
        }

        // Could use Array.shift, but it messes with debugging console (array is emptied)
        this.processLogicalMessage(toProcess[idx]).then(() => this.processSequentially(toProcess, idx + 1));

    }

    /** Process one logical message, and return a Promise to synchronize on */
    protected processLogicalMessage(message: LogicalMessage): Promise<void> {

        if (this.messages.filter(msg => msg === message).length == 0) {
            
            this.messages.push(message);
            switch (message.command) {
                case 'addComponents':
                    return this.loadAndInsertComponents((message as AddComponents).maps);
                case 'rebindComponents':
                    this.rebindExistingComponents((message as RebindComponents).maps);
                    return Promise.resolve();
                case 'removeAllUnprotected':
                    this.clearAllUnprotectedFields();
                    return Promise.resolve();
                case 'removeAllComponents':
                    this.removeAnyExistingComponent();
                    return Promise.resolve();
                case 'setCursorPosition':
                    this.setCursorPosition((message as SetCursorPosition).cursor);
                    return Promise.resolve();
                case 'windowComponents':
                    return this.loadAndActiveWindowComponents(message as WindowComponents);
                default:
                    let errorMessage = 'Unhandled backend command "' + message.command + '"';
                    console.log(errorMessage); // Ensure this makes its way to the logs
                    throw new Error(errorMessage);
            }
        }
    }

	/** ------------------------------------ Main methods -----------------------------------  **/

    /** Load components, then insert and bind them */
    private loadAndInsertComponents(maps: Map[]): Promise<void> {

        let proms = this.loadComponents(maps);
        this.checkModalComponents(maps);

        // Now sequentially insert components (order matters)
        // TODO More complex layout may be needed here (see "Cumulative output - the ACCUM option" chapter)
        return Promise.all(proms).then((cmpFactories: Array<ComponentFactory<{}>>) => {
            for (let i = 0; i < maps.length; i++) {
                this.insertComponents(maps[i], cmpFactories[i]);
            }
        });
    }

    /** Bind fields values and attributes to existing components */
    private rebindExistingComponents(maps: Map[]): void {

        for (let i = 0; i < maps.length; i++) {
            let map = maps[i];

            // Find the existing component for this map
            let component: ComponentRef<any> = this.componentsByName[map.component];
            if (component === undefined) {
                throw new Error('Component not found in existing ones, cannot rebind: ' + map.component);
            }

            this.decodeFields(component.instance, map);

            /** Clone fields object to trigger method "set data( data: Data )" from dynamic field component */
	        let fields : Field[] = map.fields; 
	        for (let i = 0; i < fields.length; i++) {
	            let field: Field = fields[i];
                let data: any = component.instance[field.id];
                if (!Array.isArray(data)){ // TODO: Treat array ?
                    this.cloneToUpdate(data, component.instance, field.id);
                }
			}
        }
    }
    
    /** Clear the contents of all currently displayed, unprotected fields, and reset their MDT flag */
    private clearAllUnprotectedFields(): void {
        for (let componentRef of this.injectedComponents) {
            let component = componentRef.instance;

            for (let fieldId of component.FIELDS) {
                let field = component[fieldId];
                if (Array.isArray(field)) {
                    // TODO What should we do here? Is there a 5250 equivalent behavior?
                    continue;
                }

                let data: Data = field;
                let unprotected: boolean = data.attributes && data.attributes.protection === 'UNPROT';
                if (!unprotected) {
                    continue;
                }

                data.value = data.initialValue = undefined; // An empty string will confuse Data#isModified()
                data.clearModified();
                this.cloneToUpdate(data, component, fieldId);
            }
        }
    }
    
    private removeAnyExistingComponent(): void {
        for (let i = 0; i < this.injectedComponents.length; i++) {
            this.injectedComponents[i].destroy();
        }
        this.injectedComponents = [];
        this.injectedModalComponents = [];
        this.componentsByName = {};
        this.modalComponentsByName = {};
        this.fieldsByPosition = {};
    }
    
    private setCursorPosition(cursor: number): void {
    	let injectedField: any = this.getFieldByPosition(cursor);
    	injectedField.initialCursor = true;
    }

    /** Load Window components, then insert and bind them */
    protected loadAndActiveWindowComponents(message: WindowComponents) {
        let maps = this.loadWindowComponents(message.maps);
        let proms = this.loadComponents(maps);
        
        // Now sequentially insert components (order matters)
        return Promise.all(proms).then((cmpFactories: Array<ComponentFactory<{}>>) => {
            for (let i = 0; i < maps.length; i++) {    
                let componentName = maps[i].component;  
                if (this.decodeFieldsSubComponent()) {
                    if((maps[i].windowRef !== undefined && maps[i].windowRef == this.getName()) || componentName == this.getName()){
                        this.insertComponents(maps[i], cmpFactories[i]);
                    }
                } else {
                    let modalName = maps[i].windowRef !== undefined ? maps[i].windowRef.toString() : componentName;
                    if(maps[i].windowRef === undefined) {
                        // Build component, then bind message to UI
                        let component = this.dynamicTarget.createComponent(cmpFactories[i]);
                        this.injectedComponents.push(component);
                        this.componentsByName[componentName] = component;

                        this.modalComponentsByName[componentName] = component;
                        this.injectedModalComponents.push(component);

                        // Send messages to the modal component
                        this.modalService.activeModal(modalName).next({message : message, parentComponent : this});
                    }
                }
            }
        });
    }

    /** ----------------------------------------------------------------------------------------  **/

    /** ------------------------------------ Common methods -----------------------------------  **/

    /** Clone and set Data describing a field (make sure modification is displayed; V7-3558) */
    private cloneToUpdate(data:Data, componentInstance, fieldId:string) {
        let cloneData = data.clone();
        let pos: number = data.attributes.line * 80 + data.attributes.column;
        this.fieldsByPosition[pos] = cloneData;
        componentInstance[fieldId] = cloneData;
    }

    /** Set up and return components loading/building factories */
    private loadComponents(maps: Map[]): Array<Promise<ComponentFactory<{}>>> {
        // First load and setup asynchronously modules defining map components
        let proms: Array<Promise<ComponentFactory<{}>>> = [];
        for (let i = 0; i < maps.length; i++) {
            let map = maps[i];

            // Search for the angular type corresponding to this component name
            let componentType = this.getMapComponent(map.component);
            if (componentType == null) {
                throw new Error('Unknown component: "' + map.component + '"');
            }

            // Load component-owning module dynamically
            let componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentType);
            proms.push(Promise.resolve(componentFactory));
        }

        return proms;
    }
    


    // Build component or reuse the existing one
    private insertComponents(map: Map, cmpFactory : ComponentFactory<{}>) {
        // Get existing component or build a new one, then bind message to UI
        let existingComponent = this.getComponent(map.component);
        if(existingComponent !== undefined){
            this.decodeFields(existingComponent.instance, map);
        } else {
        	// Build component, then bind message to UI
            let component = this.dynamicTarget.createComponent(cmpFactory);
            
            this.injectedComponents.push(component);
            this.componentsByName[map.component] = component;
            this.decodeFields(component.instance, map);
        }
    }

    /** Initialize a map component with JSON informations provided by the backend */
    private decodeFields(map: any, inputMap: any): void {

        /** Map technicals fields */
        if (inputMap.overlay !== undefined) {
        	this.mapFieldToData( map, 'overlay', inputMap.overlay);
        }
        this.mapFieldToData( map, 'startLineNumber',  inputMap.startLineNumber);

        /** Map to business fields */
        let fields : Field[] = inputMap.fields; 
        for (let i = 0; i < fields.length; i++) {
            let field: any = fields[i];
            let data: any = map[field.id];
            if (data == null) {
                throw new Error('No entry in map for field ' + field.id)
            }

            // Reflexively set field value
            if (field.data !== undefined) {
                data.value = field.data;
            } else if (field.fields !== undefined && Array.isArray(data)) {
                if(field.component !== undefined){
                    this.subComponentsByName[field.component] = data;
                }

                for (let subMap of field.fields) {
                    let arrayItem : any ={};
                    let index=0;
                    for (let subField of subMap.fields) {
                        let subData = new Data ;
                        subData.value = subField.data;
                        this.fillData(subData, subField);
                        arrayItem[subField.id] = subData;
                    }
                    arrayItem["FIELDS"] = subMap.fields;
                    arrayItem['forceModified'] = subMap.forceModified
                    data.push(arrayItem);
                   
                    index++;
                }
            }

            // Make sure that subsequent calls to Data instance methods will be possible
            // Required since objects generated in components are "properties only" objects and not instances of Data
            if (!Array.isArray(data)) {
                Object.setPrototypeOf(data, Data.prototype);
            }
            
            if (inputMap.cursorLine !== undefined && inputMap.cursorColumn !== undefined) {
                data.cursorLine = inputMap.cursorLine;
                data.cursorColumn = inputMap.cursorColumn;
            }
            
            // Ensure attributes are set on component
            this.fillData(data, field);
        }

        // If the component contains a subfile, update its record number so the correct page will be displayed
        if(map.isSubfileControl == true){
        	map.updateSubfile();
        }
    }

    /* Fill data from field. Code also expects this to be called on Array => "data" can be of type Data or Array */
    private fillData(data : any, field: Field): void {

        // Keep track of initial value (for "modified" detection purpose)
        data.initialValue = data.value;

        if (field.attributes !== undefined) {
            // Provide attributes for decoding by the dynamic-field component
            data.attributes = field.attributes;

            // Signal that field data must be sent inconditionnaly (even if not modified)
            // Keep existing value if we did not receive attributes (V7-139, V7-127)
            if (Array.isArray(data)) {
                // TODO Probably not needed since decodeFields also sets forceModified in the Array case (V7-7297)
                data['forceModified'] = field.attributes.forceModified;
            } else {
                let actualData: Data = data as Data;
                // This test gives us some room for not sending forceModified in attributes in the future
                if (field.attributes.forceModified !== undefined) {
                    // Usual "forceModified from backend will set the MDT on the terminal" scenario
                    if (field.attributes.forceModified) {
                        actualData.setModified();
                    } else {
                        // Used to reset the MDT programmatically; only activated for CICS/BMS now
                        if (this.configuration.forceModifiedCanResetMDT) {
                            actualData.clearModified();
                        }
                    }
                }
                
            }

            // Update consultation mode (readOnly & disabled)
            data.disabled =  field.attributes && field.attributes.protection === 'ASKIP';
            data.protected = field.attributes && field.attributes.protection === 'PROT';
            
            let pos: number = data.attributes.line * 80 + data.attributes.column;
            this.fieldsByPosition[pos] = data;
        }

        if (field.initialCursor !== undefined) {
            data.initialCursor = field.initialCursor;
        }
    }

    /* Map field to data value. */
    private mapFieldToData(map : any, data: string, field: any): void {
        if (map[data] !== undefined && field !== undefined) {
            map[data] = field;
        }
    }    
    
    /** --------------------------------------------------------------------------------------  **/
    
    /** ------------------------------------ Modal methods -----------------------------------  **/

    /** Separate window component to be created from existing ones */
    private loadWindowComponents(maps: WindowMap[]): WindowMap[] {
        let newMaps: WindowMap[] = [];
        let existingComponent: { [key: string]: RebindComponents } = {}
        for (let i = 0; i < maps.length; i++) {
            let modalName = maps[i].windowRef !== undefined ? maps[i].windowRef.toString() : maps[i].component.toString();

            // Destroy all windows that overlay the current one
            this.destroyOverlayingModalComponents(modalName, maps[i].remove);

            // If the modal already exists, just update the component
            // else, create the modal component
            let modal = this.getModal(modalName);
            if(modal === undefined){
                // The modal doesn't exist so need to be created
                newMaps.push(maps[i]);
            } else {
                // The modal exists, just recreate components
                if(existingComponent[modalName] == undefined){
                    let addMessage: AddComponents = { command: 'addComponents', maps: []};
                    addMessage.maps.push(maps[i]);
                    existingComponent[modalName] = addMessage;
                } else {
                    existingComponent[modalName].maps.push(maps[i]);
                }

                // For all components from existing modal, send a message
                if(maps[i].overlay !== true){   
                    let removeMessage: RemoveAllComponents = { command: 'removeAllComponents' };
                    this.modalService.activeModal(modalName).next({message : removeMessage, parentComponent : this});
                }
                this.modalService.activeModal(modalName).next({message : existingComponent[modalName], parentComponent : this});
            }
        }

        // Return the new modal
        return newMaps;
    }

    /** Destroy All Modal components if there is a message to main window (except standard-messaline) */
    private checkModalComponents(maps: Map[]): void {
        if(this.injectedModalComponents.length == 0){
            return;
        }

        let destroy: boolean = false;
        for (let i = 0; i < maps.length; i++) {
            if(maps[i].component !== 'standard-messageline'){
                destroy = true;
            }
        }
        if(destroy){
            this.destroyAllModalComponents();
        }
    }
    
    /** Destroy All Modal components */
    private destroyAllModalComponents(): void {
        for (let i = 0; i < this.injectedModalComponents.length; i++) {
            const index = this.injectedComponents.indexOf(this.injectedModalComponents[i], 0);
            if (index > -1) {
                this.injectedComponents.splice(index, 1);
            }
            this.injectedModalComponents[i].destroy();

        }
        this.injectedModalComponents = [];
		this.modalComponentsByName = {};
    }
    
    /** Destroy All Modal components above the message's one */
    private destroyOverlayingModalComponents(modalName: String, remove: boolean): void {
    	// If the window message has a remove property, remove all windows
        if(remove){
            this.destroyAllModalComponents();
        }

        // Get current window index to remove overlaying windows
        let startIndex = -1;
        let keys: any = Object.keys(this.modalComponentsByName);
        for (let key of keys) {
            if(key == modalName){
                startIndex = this.injectedModalComponents.indexOf(this.modalComponentsByName[key], 0) + 1;
            } else if(startIndex > -1) {
                delete this.modalComponentsByName[key];
            }
        }
        if(startIndex > 0 ){
            for (let i = startIndex; i < this.injectedModalComponents.length; i++) {
                console.log('Destroy Modal Component' + i);
                const index = this.injectedComponents.indexOf(this.injectedModalComponents[i], 0);
                if (index > -1) {
                    this.injectedComponents.splice(index, 1);
                }
                this.injectedModalComponents[i].destroy();

            }
            this.injectedModalComponents = this.injectedModalComponents.slice( 0 , startIndex );
        }
    }
    
    public getModalComponent() : { [key: string]: ComponentRef<any> } {
        return this.modalComponentsByName;
    }
    
    /** ----------------------------------------------------------------------------------------  **/
    
    /** ----------------------------------------------------------------------------------------  **/
    /** React to attention keys */
    @HostListener('document:keydown', ['$event'])
    onKeyDownListener(e: KeyboardEvent) {
    	// If the current component is not the one on the top, stop listening
        if(!this.isTopComponent()){
            return;
        }
        
        this.displayErrorMessage('')
    	let activeElementDoc : Element = document.activeElement;
        let activeElement: string = activeElementDoc.id;
        let attentionKey: string = null;

        let myElement = document.getElementById(activeElement);
        let cursorPosition: number = 0;
        if ( e.target instanceof HTMLInputElement ) {
            cursorPosition = e.target.selectionStart; 
        }

        // Robustness switch from key / which / keyCode
        // See https://keycode.info/ for key codes
        let key = e.key || '';
        let keyCode = e.which || e.keyCode || -1;
        let groups = [];
        if (keyCode == 13 || key === 'Enter') {
            attentionKey = 'ENTER';
        }  else if (this.transactionService.is5250() && (keyCode == 33 || key === 'PageUp')) {
            if(!this.pagingSFL(e)){
                attentionKey = 'PAGEUP';
            }
        }  else if (this.transactionService.is5250() && (keyCode == 34 || key === 'PageDown')) {
            if(!this.pagingSFL(e)){
                attentionKey = 'PAGEDOWN';
            }
        } else if ((keyCode == 112 && e.ctrlKey) || (keyCode == 45 && e.altKey)) {
            // Ctrl + F1 or Alt + Insert for PA1 (V7-4104)
            attentionKey = 'PA1';
        } else if ((keyCode == 113 && e.ctrlKey) || (keyCode == 36 && e.altKey)) {
            // Ctrl + F2 or Alt + Home for PA2 (V7-4104)
            attentionKey = 'PA2';
        } else if ((keyCode == 114 && e.ctrlKey) || (keyCode == 33 && e.shiftKey)) {
            // Ctrl + F3 or Shift + PageUp for PA3 (V7-4104)
            attentionKey = 'PA3';
        }  else if (keyCode >= 112 && keyCode <= 123) {
			let pfk = (keyCode - 111);
			if(!this.processDropFold(e)) {
				if (e.shiftKey) {
					// Shift + Fx for PF13 to PF24 (V7-2657)
					pfk += 12;
				}
            	attentionKey = 'PF' + pfk;
            }
        } else if (groups = key.match(/^F(\d+)$/)) {
            attentionKey = 'PF' + groups[1];
        } else if (keyCode == 19) {
            // "Pause" key on a PC keyboard
            attentionKey = 'CLEAR';
        }

        if (attentionKey !== null) {
            console.log('Attention key pressed (' + attentionKey + ')');
            e.stopImmediatePropagation();
            e.preventDefault();
            

            // Build a message to the backend
            let termMessage: any = { 'attentionKey': attentionKey, 'activeField': activeElement, 'cursorPosition': cursorPosition, 'fields': [] };
            for (var m = 0; m < this.injectedComponents.length; m++) {
                let injectedComponent: any = this.injectedComponents[m];
                let componentName: string = this.getComponentName(injectedComponent);
                let map: any = injectedComponent.instance;

                // Protection (CTL into destroyed window case)
                if (map.FIELDS !== undefined) {
	                // Collect fields value and their "modified" status
	                let FIELDS: string[] = map.FIELDS;
	                for (var i = 0; i < FIELDS.length; i++) {
	                    let fieldName: string = FIELDS[i];
	                    let data: Data = map[fieldName];
	                    if(this.configuration.uppercaseInput){
	                		if (data && data.value){
                        		data.value = data.value.toUpperCase();
                    		}
	                	}
	                    if (Array.isArray(data)) {
                            let subComponentName: string = this.getSubComponentName(data);

	                   		let index=0;
	                    	for (var a = 0; a < data.length; a++) {
	                    		let arrayData = data[a];
	                            // An field on row at least is modified
	                            let rowModified: boolean = false;
	                    		for (let subFieldName of arrayData.FIELDS) {
	                    			let subField: Data = arrayData[subFieldName.id];
	                                rowModified = rowModified || subField.isModified();
	                            }
	                    		for (let subFieldName of arrayData.FIELDS) {
	                    			let subField: Data = arrayData[subFieldName.id];
	                                let modified: boolean = subField.isModified();
				                    /** Field value is only sent if modified (V7-130). It could be modified because :
                                     - 1 field of row at least has been modified (or is set modified explicitely)
                                     - the current field has been modified (or is set modified explicitely)
                                     - all the row is set modified explicitely (SLFNXTCHG on SFL)
                                    */
				                    if (rowModified || modified || arrayData.forceModified) {
				                        let fieldState: any = {"component": subComponentName, 'id': subFieldName.id + "_" + index, 'value': subField.value };
				                        termMessage.fields.push(fieldState);
				                    }
				                }
	                    		index++;
	                    	}
	                    } else {
		                    // Field value is only sent if modified (V7-130)
		                    if (data.isModified()) {
		                        let fieldState: any = {"component": componentName, 'id': fieldName, 'value': data.value, ...(data.attributes !== undefined && data.attributes.isPassword && {'ispassword': data.attributes.isPassword})};
		                        termMessage.fields.push(fieldState);
		                    }
		                }
	                }
	            }
            }

            AbstTermComponent.isSpinning = true;

            // Send message to frontend; wait for an answer to react on
            this.transactionService.runTransaction(this.nextTransactionId, termMessage)
                .then((message: BackendMessage) => this.onReceivedMessage(message))//.then(() => console.log("apres receive"))
                .catch((ex) => {
                    console.error('Error invoking next transaction', ex);
                });
        }
    }
    
    /** ----------------------------------------------------------------------------------------  **/
    
    /** ------------------------------------ Utility methods -----------------------------------  **/
    
    /** Try to pag on Subfile, if paging is done by the table (doPaging returns false), return true
     * If the paging is not done, check following subfile component and return false if no paging has been done.
    */
    private pagingSFL(key: KeyboardEvent): boolean {
        let result = false;
        for (var m = 0; m < this.injectedComponents.length; m++) {
            let injectedComponent: any = this.injectedComponents[m];
            let map: any = injectedComponent.instance;
            if(map.isSubfileControl == true) {
                if(!map.doPaging(key)) {
                    return true;
                }
            }
        }
        return result;
    }

    private isTopComponent(): boolean {
        if(this.parentComponent === undefined){
            return this.injectedModalComponents.length == 0;
        } else {
            // All modal are built from the root component
            let keys: any = Object.keys(this.parentComponent.getModalComponent());
            return keys[keys.length - 1] == this.getName();
        }
    }

    private displayErrorMessage(msg: string) {
        // Find the existing component for this map
        let component: ComponentRef<any> = this.componentsByName["standard-messageline"];
        if (component === undefined) {
            return;
        }

        let data: any = component.instance["messageline"];
        if (data == null) {
            return;
        }

        data.value = msg;
    }

    /** Get component name */
    private getComponentName(injectedComponent: ComponentRef<any>): string {
		let keys: any = Object.keys(this.componentsByName);
        for (let key of keys) {
        	let component: ComponentRef<any> = this.componentsByName[key];
            if (component === injectedComponent) {
            	return key;
            }
        }
        return "";
    }

    /** Get sub-component (array) name */
    private getSubComponentName(data: any): string {
        let keys: any = Object.keys(this.subComponentsByName);
        for (let key of keys) {
            let component: ComponentRef<any> = this.subComponentsByName[key];
            if (component === data) {
                return key;
            }
        }
        return "";
    }
    
    private processDropFold(key: KeyboardEvent): boolean {
        for (var m = 0; m < this.injectedComponents.length; m++) {
            let injectedComponent: any = this.injectedComponents[m];
            let map: any = injectedComponent.instance;
            if(map.isSubfileControl == true) {
                if(map.doDropFold(key)) {
                    key.stopImmediatePropagation();
                    key.preventDefault();
                    return true;
                }
            }
        }
        return false;
    }
    
    
    /** ----------------------------------------------------------------------------------------  **/
}
