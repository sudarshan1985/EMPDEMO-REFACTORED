import {Component, ContentChild, Input, TemplateRef} from '@angular/core';

enum More {
    More = "More...", Plus = '\xa0' + "+" +'\xa0' , Empty = ""
}

enum Bottom {
    Bottom = "Bottom", Empty = ""
}

export enum Paging {
    File = 0,
	Done,
	Component,
	Invalid
}

@Component({
    moduleId: module.id,
    selector: 'app-table',
    templateUrl: './table.component.html'
})

export class TableComponent {
    @ContentChild(TemplateRef) templateRef: TemplateRef<any>;

    @Input() rows: any[];
    @Input() nbLinesByRow: number;
    @Input() nbDisplayedEntries: number;
    @Input() startLineNumber: number;
    @Input() windowOffset: number;

    // End of array
    private end: boolean;
    private bottom: boolean;

    // If valued to "MORE" used pair More/Bottom
    // else used pair +/[empty]
    private pageDown: String;

    // Index from which display array items
    private recordNumber: number = 0;
    private top: true;

    // Nb record by page
    private numberOfRecordsPerPage: number = 0;

    private labelMore:More  = More.More;
    private labelBottom:Bottom = Bottom.Bottom;
    
    private dspMode: string = "*DS3";
    
    // Display table or not
    public display: true;
    
    // Drop status : TRUE = folded (expanded); FALSE = dropped (collapsed or truncated)
    public dropped: boolean = false;
    public dropCommand: String;
	public foldCommand: String;
    public dropFoldClassName: string = undefined;
    
    ngOnInit(): void {
        if (this.rows['attributes'] !== undefined) {
       		let attributes = this.rows['attributes'];
	        this.dropCommand = attributes.dropCommand;
	        this.foldCommand = attributes.foldCommand;

            // Initialize dropped flag and relative className
            if(this.dropCommand && this.foldCommand) {
                this.dropFoldClassName = 'fold_line';
                this.dropped = true;
            } else if (this.foldCommand) {
                this.dropFoldClassName = 'fold_line';
                this.dropped = true;
            } else if (this.dropCommand) {
                this.dropFoldClassName = 'drop_line';
                this.dropped = false;
            }
            this.dspMode = attributes.dspMode;
            this.end= attributes.end;
            if (this.rows.length > 0) {
                this.pageDown = attributes.pageDown;
                this.recordNumber = attributes.recordNumber;
                if (!this.recordNumber) {
                    this.recordNumber = 0;
                } else {
                    this.recordNumber -= 1; 
                }
                this.top = attributes.top;
                this.display = attributes.display;
                this.numberOfRecordsPerPage = attributes.numberOfRecordsPerPage;
                this.bottom = this.isAtBottom();          
                this.changeLabels();
            }
        }
    }

	public keyEvent(event: KeyboardEvent) { 

        let nbDisplayedEntriesLoc = this.getNbDisplayedEntries();
        if(event.key === 'PageDown') {
            if(this.isAtBottom()){
                return true;
            }
            this.recordNumber = this.recordNumber + nbDisplayedEntriesLoc;
            
		} else if(event.key === 'PageUp') {
            this.recordNumber = this.recordNumber - nbDisplayedEntriesLoc;
            if (this.recordNumber < 0) {
                this.recordNumber = 0;
                return true;
            }
        }
        this.bottom = this.isAtBottom();
        return this.recordNumber > this.rows.length - 1;
	}

    isAtBottom() : boolean {
        // End of buffer
        let endBuffer =  (this.recordNumber + this.getNbDisplayedEntries()) >= this.rows.length;
        
        let endAll = endBuffer;

        // AND end backend flag
        endAll = endAll && this.end;
        return endAll;
    }

    public updateAttribute(attr: any) { 

        if(attr.dspMode){
            this.dspMode = attr.dspMode;
        }
        if(attr.dropCommand){
            this.dropCommand = attr.dropCommand;
        }
        if(attr.foldCommand){
            this.foldCommand = attr.foldCommand;
        }
        if(attr.pageDown){
            this.pageDown = attr.pageDown;
        }
        if(attr.end){
            this.end = attr.end;
        }
        if (!attr.recordNumber) {
            this.recordNumber = 0;
        } else if(this.rows.length != 0 && this.recordNumber > this.rows.length - 1){
            this.recordNumber = this.rows.length - 1; 
        } else {
            this.recordNumber = attr.recordNumber - 1; 
        }
        if(attr.top){
            this.top = attr.top;
        }
        if(attr.display){
            this.display = attr.display;
        }
        this.changeLabels();
	}
	
    changeLabels(): void {
        if (this.pageDown == "MORE" ) {
            this.labelMore  = More.More;
        } else if (this.pageDown == "PLUS" ) {
            this.labelMore  = More.Plus;
        } else {
            this.labelMore  = More.Empty;
        }
    }

    getEndLabel(): String {
        if (this.end && this.bottom) {
            return this.labelBottom;
        } else {
            return this.labelMore;
        }
    }

    // Compute class to apply for indicator label
    positionLabel(): String {

        let classes = "tab_end_ind ";
        let isA7: boolean = this.dspMode === "*DS4";
        let defaultWidth = isA7 ? 132 : 80;

        if (this.isAtBottom()) {
            let lengthLabel = this.labelBottom.length;
            // -1
            //lengthLabel -= lengthLabel;
            if ( this.labelBottom == Bottom.Bottom) {
                if (this.windowOffset == undefined) {
                    classes += "lgo_" + (defaultWidth - lengthLabel)  + " ";
                } else {
                    classes += "lgo_" + (this.windowOffset - 1 - lengthLabel) + " ";
                }
                classes += "lgr_0" + lengthLabel + " ";
            } else {
                // Nothing, disable by ngIf
                return "";
            }
        } else {
            let lengthLabel = this.labelMore.length;
            if ( this.labelMore == More.More) {
                if (this.windowOffset == undefined) {
                    classes += "lgo_" + (defaultWidth - lengthLabel)  + " ";
                } else {
                    classes += "lgo_" + (this.windowOffset - 1 - lengthLabel) +  " ";
                }
                classes += "lgr_0" + lengthLabel + " ";
            } else {
                classes += "lgo_" + (defaultWidth - 2) + " ";
                classes += "lgr_03 ";
            }
        }
        
        classes += "white";

        return classes;
    }

    getNbDisplayedEntries(): number {

        if (this.dropped) {
            return this.nbDisplayedEntries;
        } 

        let nbDisplayedEntriesLoc = this.nbDisplayedEntries;
        if (this.nbLinesByRow) {
            nbDisplayedEntriesLoc = this.nbDisplayedEntries * this.nbLinesByRow;
        }

        return nbDisplayedEntriesLoc;
    }

    // Return true if i th element must be displayed
    displayed(index: number): boolean {
        let display = false;
        
        if (this.top) {
            let nbFirst :number = this.recordNumber;
            let nbLast :number = nbFirst + this.getNbDisplayedEntries() - 1;

            if (index >= nbFirst && index <= nbLast) {
                display = true;
            }
        } else {

            if (this.getNbDisplayedEntries() != 0) {
                let pageNbBeforeItem : number = this.recordNumber / this.getNbDisplayedEntries();
                let nbFirst :number = parseInt(String(pageNbBeforeItem)) * this.getNbDisplayedEntries();
                let nbLast :number = nbFirst + this.getNbDisplayedEntries() - 1;

                if (index >= nbFirst && index <= nbLast) {
                    display = true;
                }
            } else {
                console.log("Cannot display array items because number of items by page is zero");
            }
        }

        return display;
    }

    // Compute style to apply in order to put "+" indicator label on last displayed line
    overlayLastLine() {

        let style = "{";
        let nbDisplayedEntriesLoc = this.nbDisplayedEntries;//this.getNbDisplayedEntries();
        if (this.labelMore == More.Plus) {
            if (!this.isAtBottom()) {
                style += '"margin-top": "-1.4em"';
            }
        }
        style += "}";
        return JSON.parse(style);
    }

    public handleDropFold(event: KeyboardEvent) {

        let className: string = undefined
        if('C' + event.key === this.dropCommand) {
            className = 'drop_line';
        } else if('C' + event.key === this.foldCommand) {
            className = 'fold_line';
        }
        if(!className) {
            return false;
        }

        // Switch drop flag
        this.dropped = !this.dropped;

        if (this.dropped) {
           // Nothing
        } else {
            this.recordNumber = Math.trunc(this.recordNumber / this.getNbDisplayedEntries()) * this.getNbDisplayedEntries();;
        }

        this.bottom = this.isAtBottom();

        if(this.updateFolding()) {
            return true;
        }
 
        return false;
	}

    public ngAfterViewChecked(): void {
        this.updateFolding();
    }

    updateFolding() : boolean {

       if(this.dropFoldClassName) {
            let displayStyle = this.dropped ? 'block' : 'none';
            [].forEach.call(document.getElementsByClassName(this.dropFoldClassName), function(el) {
                el.style.display = displayStyle;
            });

            return true;
        }
        return false;
    }
}

