export class UserInfo {
    termId?: string;
    userId?: string;
    userName?: string;
    netName?: string;
    opId?: string;
}

export class UserInfoResponse {
    message?: string;
    success?: boolean;
}
